﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace RequisitionAPI.Data
{
    [Table("Vendors")]
    public partial class Vendor
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string AccountName { get; set; }
        public double AccountNo { get; set; }
        public double Phone { get; set; }
        public string RcNo { get; set; }
        public string BusinessNo { get; set; }
        public string Nature { get; set; }

    }
}
