﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RequisitionAPI.Data
{
    public class Items
    {       [Key]
        public int Id { get; set; }       
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public string Description { get; set; }
        public int VendorId { get; set; }
        public int UserId { get; set; }
        public DateTime DateTime { get; set; } = DateTime.UtcNow;
        public Vendor Vendor { get; set; }
        public User User { get; set; }

    }
}