﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RequisitionAPI.Data.DTOs
{
    public class UserDTO
    {
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Department { get; set; }

        public string Email { get; set; }

        public string PhoneNo { get; set; }

        public int RoleId { get; set; }

        public string Company { get; set; }

        public string Password { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
        public virtual IList<Requisition> Requisitions { get; set; }
        public virtual Role Role { get; set; }
    }

    public class UserCreateDTO
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string PhoneNo { get; set; }
        [Required]
        public int RoleId { get; set; }
        [Required]
        public string Company { get; set; }
        [Required]
        public string Password { get; set; }
    }
    public class UserUpdateDTO
    {
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string PhoneNo { get; set; }
        [Required]
        public string Company { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
