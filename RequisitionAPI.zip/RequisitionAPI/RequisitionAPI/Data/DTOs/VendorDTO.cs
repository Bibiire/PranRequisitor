﻿using System;
namespace RequisitionAPI.Data.DTOs
{
    public class VendorDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string AccountName { get; set; }
        public decimal AccountNo { get; set; }
        public decimal Phone { get; set; }
        public string RcNo { get; set; }
        public string BusinessNo { get; set; }
        public string Nature { get; set; }
    }

    public class VendorCreateDTO
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string AccountName { get; set; }
        public decimal AccountNo { get; set; }
        public decimal Phone { get; set; }
        public string RcNo { get; set; }
        public string BusinessNo { get; set; }
        public string Nature { get; set; }
    }
    public class VendorUpdateDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string AccountName { get; set; }
        public decimal AccountNo { get; set; }
        public decimal Phone { get; set; }
        public string RcNo { get; set; }
        public string BusinessNo { get; set; }
        public string Nature { get; set; }
    }
}
