﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RequisitionAPI.Data.DTOs
{
    public class RequisitionDTO
    {
        public int Id { get; set; }
        
        
        public int UserId { get; set; }
        public int VendorId { get; set; }
        public int ItemId { get; set; }
        public ICollection<Items> Items { get; set; }
        public virtual UserDTO User { get; set; }
        public virtual VendorDTO Vendor { get; set; }

    }

    public class RequisitionCreateDTO
    {
        
        [Required]
        public int UserId { get; set; }
        [Required]
        public int VendorId { get; set; }
        public ICollection<Items> Items { get; set; }

    }

    public class RequisitionUpdateDTO
    {
        
        public int Id { get; set; }
        [Required]
        public int ItemId { get; set; }
        public ICollection<Items> Items { get; set; }
    }
}
