﻿using System;
namespace RequisitionAPI.Data.DTOs
{
    public class ItemDTO
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public string Description { get; set; }
        public int VendorId { get; set; }
        public int UserId { get; set; }
        public Vendor Vendor { get; set; }
        public User User { get; set; }
    }

    public class ItemCreateDTO
    {
        
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public string Description { get; set; }
        public int VendorId { get; set; }
        public int UserId { get; set; }

    }

    public class ItemUpdateDTO
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public string Currency { get; set; }
        public decimal TotalPrice { get; set; }
        public string Description { get; set; }
        public int VendorId { get; set; }
        public int UserId { get; set; }

    }
}
