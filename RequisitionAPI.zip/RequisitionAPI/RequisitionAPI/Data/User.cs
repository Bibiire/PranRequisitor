﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace RequisitionAPI.Data
{
    [Table("Users")]
    public partial class User
    {
        public int Id { get; set; }
        
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Department { get; set; }

        public string Email { get; set; }

        public string PhoneNo { get; set; }

        public int RoleId { get; set; }

        public string Company { get; set; }
        public String? Image { get; set; }
        public string Password { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
        public virtual IList<Requisition> Requisitions { get; set; }
        public virtual Role Role { get; set; }

        
    }
}
