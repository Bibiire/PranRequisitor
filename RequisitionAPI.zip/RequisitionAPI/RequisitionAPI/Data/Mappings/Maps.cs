﻿using System;
using AutoMapper;
using RequisitionAPI.Data.DTOs;

namespace RequisitionAPI.Data.Mappings
{
    public class Maps : Profile
    {
        public Maps()
        {
            CreateMap<User, UserDTO>().ReverseMap();
            CreateMap<User, UserCreateDTO>().ReverseMap();
            CreateMap<User, UserUpdateDTO>().ReverseMap();
            CreateMap<Vendor, VendorDTO>().ReverseMap();
            CreateMap<Vendor, VendorCreateDTO>().ReverseMap();
            CreateMap<Vendor, VendorUpdateDTO>().ReverseMap();
            CreateMap<Requisition, RequisitionDTO>().ReverseMap();
            CreateMap<Requisition, RequisitionCreateDTO>().ReverseMap();
            CreateMap<Requisition, RequisitionUpdateDTO>().ReverseMap();
            CreateMap<Items, ItemDTO>().ReverseMap();
            CreateMap<Items, ItemCreateDTO>().ReverseMap();
            CreateMap<Items, ItemUpdateDTO>().ReverseMap();

        }

    }
}
