﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace RequisitionAPI.Data
{
    
    [Table("Roles")]
    public class Role
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;

    }
}