﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RequisitionAPI.Data
{
    public class Requisition
    {
        [Key]
        public int Id { get; set; }
        public bool Status { get; set; }
        public int UserId { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
        public User User { get; set; }
        public int ItemId { get; set; }
        public Items Items { get; set; }
    }
}
