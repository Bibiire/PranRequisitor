﻿using System;
using System.Threading.Tasks;
using RequisitionAPI.Data;

namespace RequisitionAPI.Contracts
{
    public interface IRequisitionRepository : IRepositoryBase<Requisition>
    {
        public Task<Requisition> getReqByUserId(int userId);
    }
}
