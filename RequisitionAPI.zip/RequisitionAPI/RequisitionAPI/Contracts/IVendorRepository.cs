﻿using System;
using RequisitionAPI.Data;

namespace RequisitionAPI.Contracts
{
    public interface IVendorRepository : IRepositoryBase<Vendor>
    {

    }
}
