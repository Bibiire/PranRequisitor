﻿using System;
using System.Threading.Tasks;
using RequisitionAPI.Data;

namespace RequisitionAPI.Contracts
{
    public interface IUserRepository : IRepositoryBase<User>
    {
        public Task<User> Login(User loginInfo);

    }
}
