﻿using System;
using System.Threading.Tasks;
using RequisitionAPI.Data;

namespace RequisitionAPI.Contracts
{
    public interface IRoleRepository
    {
        Task<bool> CreateRole(Role newRole);
        Task<bool> Save();
        Task<bool> isExists(int id);
    }
}
