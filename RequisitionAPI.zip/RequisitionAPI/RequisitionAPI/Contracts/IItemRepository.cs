﻿using System;
using RequisitionAPI.Data;

namespace RequisitionAPI.Contracts
{
    public interface IItemRepository : IRepositoryBase<Items>
    {

    }
}
