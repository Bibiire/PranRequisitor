﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;
using RequisitionAPI.Data.DTOs;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RequisitionAPI.Controllers
{
    [Route("api/[controller]")]
    public class ReqController : Controller
    {
        private readonly IRequisitionRepository _requisitionRepository;
        private readonly IMapper _mapper;

        public ReqController(IRequisitionRepository requisitionRepository,
           IMapper mapper)
        {
            _requisitionRepository = requisitionRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// Get all requisitions
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetRequisitions()
        {
            try
            {
                var requisitions = await _requisitionRepository.FindAll();
                var response = _mapper.Map<IList<Requisition>>(requisitions);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        /// <summary>
        /// Get a requisition
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("id")]
        public async Task<IActionResult> GetRequisition(int id)
        {
            try
            {
                var requisition = await _requisitionRepository.FindById(id);
                if (requisition == null)
                {
                    return NotFound();
                }
                var response = _mapper.Map<RequisitionDTO>(requisition);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        /// <summary>
        /// Get a requisition
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("getReqByUserId")]
        public async Task<IActionResult> getReqByUserId(int id)
        {
            try
            {
                var requisition = await _requisitionRepository.getReqByUserId(id);
                if (requisition == null)
                {
                    return NotFound();
                }
                var response = _mapper.Map<RequisitionDTO>(requisition);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        /// <summary>
        /// Create a requisition
        /// </summary>
        /// <param name="requisitionDTO"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> CreateRequisition([FromBody] RequisitionCreateDTO requisitionDTO)
        {
            try
            {
                if (requisitionDTO == null)
                {
                    return BadRequest(ModelState);
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var requisition = _mapper.Map<Requisition>(requisitionDTO);
                var isSucceed = await _requisitionRepository.Create(requisition);
                if (!isSucceed)
                {
                    return InternalError($"Requisition Creation failed");
                }
                return Created("Create", new { requisition });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        /// <summary>
        /// update a requisition
        /// </summary>
        /// <param name="id"></param>
        /// <param name="requisitionDTO"></param>
        /// <returns></returns>
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateRequisition(int id, [FromBody] RequisitionUpdateDTO requisitionDTO)
        {
            if (id < 1 || requisitionDTO == null || id != requisitionDTO.Id)
            {
                return BadRequest(ModelState);
            }
            var isExists = await _requisitionRepository.isExists(id);

            if (!isExists)
            {
                return NotFound();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var requisition = _mapper.Map<Requisition>(requisitionDTO);
            var isSuccess = await _requisitionRepository.Update(requisition);
            if (!isSuccess)
            {
                return InternalError($"Update operation failed");
            }
            return NoContent();
        }

        /// <summary>
        /// Delete a requisition
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRequisition(int id)
        {
            try
            {
                if (id < 1)
                {
                    return BadRequest();
                }
                var isExists = await _requisitionRepository.isExists(id);

                if (!isExists)
                {
                    return NotFound();
                }
                var requisition = await _requisitionRepository.FindById(id);
                var isSuccess = await _requisitionRepository.Delete(requisition);
                if (!isSuccess)
                {
                    return InternalError($"Requisition Delete failed");
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        private ObjectResult InternalError(string message)
        {
            return StatusCode(500, "Something went wrong. Contact the Administrator");
        }
    }
}
