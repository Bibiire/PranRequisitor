﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RequisitionAPI.Controllers
{
    [Route("api/[controller]")]
    public class RoleController : Controller
    {
        private readonly IRoleRepository _roleRepository;

        public RoleController(IRoleRepository roleRepository)
        {
            _roleRepository = roleRepository;
        }

        [HttpPost]
        public async Task<ActionResult>Create([FromBody] Role newrole)
        {
             try
            {
                if (newrole == null)
                {
                    return BadRequest(ModelState);
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                
                var isSucceed = await _roleRepository.CreateRole(newrole);
                if (!isSucceed)
                {
                    return InternalError($"Role Creation failed");
                }
                return Created("Create", new { newrole });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        private ObjectResult InternalError(string message)
        {
            return StatusCode(500, "Something went wrong. Contact the Administrator");
        }

    }
}
