﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;
using RequisitionAPI.Data.DTOs;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RequisitionAPI.Controllers
{
    [Route("api/[controller]")]
    public class VendorsController : Controller
    {
        private readonly IVendorRepository _vendorRepository;
        private readonly IMapper _mapper;
        public VendorsController(IVendorRepository vendorRepository,
            IMapper mapper
            )
        {
            _vendorRepository = vendorRepository;
            _mapper = mapper;
        }
        /// <summary>
        /// Get all Vendors
        /// </summary>
        /// <returns>List of all Vendors</returns>
        [HttpGet]
        public async Task<IActionResult> GetVendors()
        {
            try
            {
                var vendors = await _vendorRepository.FindAll();
                var response = _mapper.Map<IList<VendorDTO>>(vendors);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }

        }

        /// <summary>
        /// Get a Vendor by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vendor Record</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetVendors(int id)
        {
            try
            {
                var vendor = await _vendorRepository.FindById(id);
                if (vendor == null)
                {
                    return NotFound();
                }
                var response = _mapper.Map<VendorDTO>(vendor);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }

        }

        /// <summary>
        /// Create a new Vendor
        /// </summary>
        /// <param name="VendorDTO"></param>
        /// <returns></returns>

        [HttpPost]
        public async Task<IActionResult> CreateVendor([FromBody] VendorCreateDTO vendorDTO)
        {
            try
            {
                if (vendorDTO == null)
                {
                    return BadRequest(ModelState);
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var vendor = _mapper.Map<Vendor>(vendorDTO);
                var isSucceed = await _vendorRepository.Create(vendor);
                if (!isSucceed)
                {
                    return InternalError($"vendor Creation failed");
                }
                return Created("Create", new { vendor });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        /// <summary>
        /// Update a vendor's Data
        /// </summary>
        /// <param name="id"></param>
        /// <param name="vendorDTO"></param>
        /// <returns></returns>
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateVendor(int id, [FromBody] VendorUpdateDTO vendorDTO)
        {
            if (id < 1 || vendorDTO == null || id != vendorDTO.Id)
            {
                return BadRequest(ModelState);
            }
            var isExists = await _vendorRepository.isExists(id);

            if (!isExists)
            {
                return NotFound();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var vendor = _mapper.Map<Vendor>(vendorDTO);
            var isSuccess = await _vendorRepository.Update(vendor);
            if (!isSuccess)
            {
                return InternalError($"Update operation failed");
            }
            return NoContent();
        }

        /// <summary>
        /// Delete a vendor
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVendor(int id)
        {
            try
            {
                if (id < 1)
                {
                    return BadRequest();
                }
                var isExists = await _vendorRepository.isExists(id);

                if (!isExists)
                {
                    return NotFound();
                }
                var vendor = await _vendorRepository.FindById(id);
                var isSuccess = await _vendorRepository.Delete(vendor);
                if (!isSuccess)
                {
                    return InternalError($"Vendor Delete failed");
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }


        private ObjectResult InternalError(string message)
        {
            return StatusCode(500, "Something went wrong. Contact the Administrator");
        }
    }
}
