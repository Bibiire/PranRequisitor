﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;
using RequisitionAPI.Data.DTOs;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RequisitionAPI.Controllers
{
    /// <summary>
    /// Endpoint Used to interact with the User.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]

    public class UsersController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;

        public UsersController(IUserRepository userRepository,
           IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// Get all Users
        /// </summary>
        /// <returns>List of all Users</returns>
        [HttpGet]
        public async Task<IActionResult> GetUsers()
        {
            try
            {
                var users = await _userRepository.FindAll();
                var response = _mapper.Map<IList<UserDTO>>(users);
                return  Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }

            
            
        }
        /// <summary>
        /// Get a User by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>User Record</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult>GetUser(int id)
        {
            try
            {
                var user = await _userRepository.FindById(id);
                if (user == null)
                {
                    return NotFound();
                }
                var response = _mapper.Map<UserDTO>(user);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }

            
        }
        /// <summary>
        /// Create a new User
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns></returns>

        [HttpPost]
        public async Task<IActionResult>CreateUser([FromBody] UserCreateDTO userDTO)
        {
            try
            {
                if (userDTO == null)
                {
                    return BadRequest(ModelState);
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var user = _mapper.Map<User>(userDTO);
                var isSucceed = await _userRepository.Create(user);
                if (!isSucceed)
                {
                    return InternalError($"User Creation failed");
                }
                return Created("Create", new { user });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }
        /// <summary>
        /// Update user data
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userDTO"></param>
        /// <returns></returns>
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] UserUpdateDTO userDTO)
        {
            if (id < 1 || userDTO == null || id != userDTO.Id)
            {
                return BadRequest(ModelState);
            }
            var isExists = await _userRepository.isExists(id);
            
            if (!isExists)
            {
                return NotFound();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var user = _mapper.Map<User>(userDTO);
            var isSuccess = await _userRepository.Update(user);
            if (!isSuccess)
            {
                return InternalError($"Update operation failed");
            }
            return NoContent();
        }

        /// <summary>
        /// Delete a User
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            try
            {
                if (id < 1)
                {
                    return BadRequest();  
                }
                var isExists = await _userRepository.isExists(id);

                if (!isExists)
                {
                    return NotFound();
                }
                var user = await _userRepository.FindById(id);
                var isSuccess = await _userRepository.Delete(user);
                if (!isSuccess)
                {
                    return InternalError($"User Delete failed");
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }



            private ObjectResult InternalError(string message)
        {
            return StatusCode(500, "Something went wrong. Contact the Administrator");
        }
       [Route("Login")]
        [HttpPost]
        public async Task<ActionResult> Login(User loginInfo)
        {
            var result = await _userRepository.Login(loginInfo);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return NotFound("No user found");
            }
        }
    }

    
}
