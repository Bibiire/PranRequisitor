﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;
using RequisitionAPI.Data.DTOs;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RequisitionAPI.Controllers
{
    [Route("api/[controller]")]
    public class ItemController : Controller
    {
        private readonly IItemRepository _itemRepository;
        private readonly IMapper _mapper;

        public ItemController(IItemRepository itemRepository, IMapper mapper)
        {
            _itemRepository = itemRepository;
            _mapper = mapper;
        }
        /// <summary>
        /// Get all Items
        /// </summary>
        /// <returns>List of all items</returns>
        [HttpGet]
        public async Task<IActionResult> GetItems()
        {
            try
            {
                var item = await _itemRepository.FindAll();
                var response = _mapper.Map<IList<Items>>(item);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }

        /// <summary>
        /// Get item by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>tems with id</returns>
        [HttpGet("id")]
        public async Task<IActionResult> GetItem(int id)
        {
            try
            {
                var item = await _itemRepository.FindById(id);
                if (item == null)
                {
                    return NotFound();
                }
                var response = _mapper.Map<ItemDTO>(item);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }
        /// <summary>
        /// Create a new Item
        /// </summary>
        /// <param name="itemDTO"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> CreateItem([FromBody] ItemCreateDTO itemDTO)
        {
            try
            {
                if (itemDTO == null)
                {
                    return BadRequest(ModelState);
                }
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var item = _mapper.Map<Items>(itemDTO);
                var isSucceed = await _itemRepository.Create(item);
                if (!isSucceed)
                {
                    return InternalError($"Item Creation failed");
                }
                return Created("Create", new { item });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }
        /// <summary>
        /// Update an Item
        /// </summary>
        /// <param name="id"></param>
        /// <param name="itemDTO"></param>
        /// <returns></returns>
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateItem(int id, [FromBody] ItemUpdateDTO itemDTO)
        {
            if (id < 1 || itemDTO == null || id != itemDTO.Id)
            {
                return BadRequest(ModelState);
            }
            var isExists = await _itemRepository.isExists(id);

            if (!isExists)
            {
                return NotFound();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var item = _mapper.Map<Items>(itemDTO);
            var isSuccess = await _itemRepository.Update(item);
            if (!isSuccess)
            {
                return InternalError($"Update operation failed");
            }
            return NoContent();
        }

        /// <summary>
        /// Delete an Item
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            try
            {
                if (id < 1)
                {
                    return BadRequest();
                }
                var isExists = await _itemRepository.isExists(id);

                if (!isExists)
                {
                    return NotFound();
                }
                var item = await _itemRepository.FindById(id);
                var isSuccess = await _itemRepository.Delete(item);
                if (!isSuccess)
                {
                    return InternalError($"Item Delete failed");
                }
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong. Contact the Administrator");
            }
        }



        private ObjectResult InternalError(string message)
        {
            return StatusCode(500, "Something went wrong. Contact the Administrator");
        }
    }
}
