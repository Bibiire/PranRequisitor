﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;

namespace RequisitionAPI.Services
{
    public class RoleRepository : IRoleRepository
    {
        public readonly AppDbContext _db;
        public RoleRepository(AppDbContext db)
        {
            _db = db;
        }


        public async Task<bool> CreateRole(Role newRole)
        {
            await _db.Roles.AddAsync(newRole);
            return await Save();
        }

        public async Task<bool> isExists(int id)
        {
            return await _db.Roles.AnyAsync(q => q.RoleId == id);
        }

        public async Task<bool> Save()
        {
            var changes = await _db.SaveChangesAsync();
            return changes > 0;
        }
    }
}