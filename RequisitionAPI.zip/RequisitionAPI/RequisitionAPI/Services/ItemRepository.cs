﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;

namespace RequisitionAPI.Services
{
    public class ItemRepository : IItemRepository
    {
        private readonly AppDbContext _db;

        public ItemRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<bool> Create(Items entity)
        {
            await _db.Items.AddAsync(entity);
            return await Save();
        }

        public async Task<bool> Delete(Items entity)
        {
            _db.Items.Remove(entity);
            return await Save();
        }

        public async Task<IList<Items>> FindAll()
        {
            var items = await _db.Items.ToListAsync();
            return items;
        }

        public async Task<Items> FindById(int id)
        {
            var item = await _db.Items.FindAsync(id);
            return item;
        }

        public async Task<bool> isExists(int id)
        {
          return await _db.Items.AnyAsync(q => q.Id == id);
        }

        public async Task<bool> Save()
        {
            var changes = await _db.SaveChangesAsync();
            return changes > 0;
        }

        public async Task<bool> Update(Items entity)
        {
            _db.Items.Update(entity);
            return await Save();
        }
    }
}
