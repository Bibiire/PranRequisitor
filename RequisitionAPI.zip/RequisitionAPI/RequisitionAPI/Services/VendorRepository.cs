﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;

namespace RequisitionAPI.Services
{
    public class VendorRepository : IVendorRepository
    {
        private readonly AppDbContext _db;
        public VendorRepository(AppDbContext db)
        {
            _db = db;
        }
        public async Task<bool> Create(Vendor entity)
        {
            await _db.Vendors.AddAsync(entity);
            return await Save();
        }

        public async Task<bool> Delete(Vendor entity)
        {
            _db.Vendors.Remove(entity);
            return await Save();
        }

        public async Task<IList<Vendor>> FindAll()
        {
            var vendors = await _db.Vendors.ToListAsync();
            return vendors;
        }

        public async Task<Vendor> FindById(int id)
        {
            var vendor = await _db.Vendors.FindAsync(id);
            return vendor;
        }

        public async Task<bool> isExists(int id)
        {
            return await _db.Vendors.AnyAsync(q => q.Id == id);
        }

        public async Task<bool> Save()
        {
            var changes = await _db.SaveChangesAsync();
            return changes > 0;
        }

        public async Task<bool> Update(Vendor entity)
        {
            _db.Vendors.Update(entity);
            return await Save();
        }
    }
}
