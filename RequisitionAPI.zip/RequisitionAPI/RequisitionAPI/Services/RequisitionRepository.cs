﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RequisitionAPI.Contracts;
using RequisitionAPI.Data;

namespace RequisitionAPI.Services
{
    public class RequisitionRepository : IRequisitionRepository
    {
        private readonly AppDbContext _db;

        public RequisitionRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<bool> Create(Requisition entity)
        {
            await _db.Requisitions.AddAsync(entity);
            return await Save();
        }

        public async Task<bool> Delete(Requisition entity)
        {
            _db.Requisitions.Remove(entity);
            return await Save();
        }

        public async Task<IList<Requisition>> FindAll()
        {
            var requisitions = await _db.Requisitions.ToListAsync();
            return requisitions;
        }

        public async Task<Requisition> FindById(int id)
        {
            var requisition = await _db.Requisitions.FindAsync();
            return requisition;
        }

         public async Task<Requisition> getReqByUserId(int userId)
        {
            var requisition = await _db.Requisitions.FirstOrDefaultAsync(u => u.UserId ==userId);
            return requisition;
        }

        public async Task<bool> isExists(int id)
        {
            return await _db.Requisitions.AnyAsync(q => q.Id == id);
        }

        public async Task<bool> Save()
        {
            var changes = await _db.SaveChangesAsync();
            return changes > 0;
        }

        public async Task<bool> Update(Requisition entity)
        {
            _db.Requisitions.Update(entity);
            return await Save();
        }
    }
}
